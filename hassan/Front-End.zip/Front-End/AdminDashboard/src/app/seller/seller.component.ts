import { Component } from '@angular/core';

@Component({
  selector: 'app-seller',
  standalone: true,
  imports: [],
  templateUrl: './seller.component.html',
  styleUrl: './seller.component.css'
})
export class SellerComponent {

}
